export default [
    {no:1, img:'https://image.goodchoice.kr/resize_360x360/exhibition/cms/Region_jeju_03_20231103163922.png',itemname:'아랍에미리트' ,su:'2',resdate:'24.10.10',price:'1000000won',name:'황태용1', tel:'010-1111-2222',email:'1111@naver.com'},
    {no:2, img:'https://image.goodchoice.kr/resize_360x360/exhibition/cms/Region_jeju_03_20231103163922.png',itemname:'미국' ,su:'4',resdate:'24.10.10',price:'70000000won',name:'황태용1', tel:'010-1111-2222',email:'1111@naver.com'},
    {no:3, img:'https://image.goodchoice.kr/resize_360x360/exhibition/cms/Region_jeju_03_20231103163922.png',itemname:'수단' ,su:'2',resdate:'24.10.10',price:'100000000won',name:'황태용1', tel:'010-1111-2222',email:'1111@naver.com'},
    {no:4, img:'https://image.goodchoice.kr/resize_360x360/exhibition/cms/Region_jeju_03_20231103163922.png',itemname:'시리아' ,su:'2',resdate:'24.10.10',price:'77000000won',name:'황태용1', tel:'010-1111-2222',email:'1111@naver.com',},


]